var searchData=
[
  ['turn_47',['turn',['../classrw2group6_1_1Mouse.html#a18890bf983b0a6d23a6915cbc51072cc',1,'rw2group6::Mouse']]],
  ['turn_5fleft_48',['turn_left',['../classrw2group6_1_1Mouse.html#a729fb38307866e35bdad5bde2e8bc97b',1,'rw2group6::Mouse']]],
  ['turn_5fright_49',['turn_right',['../classrw2group6_1_1Mouse.html#a6a358fd79456ba4ec766d7ce821a5d73',1,'rw2group6::Mouse']]]
];
