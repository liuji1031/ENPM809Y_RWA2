var indexSectionsWithContent =
{
  0: "acdfgimrstu",
  1: "acm",
  2: "r",
  3: "acdfgimrstu",
  4: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables"
};

